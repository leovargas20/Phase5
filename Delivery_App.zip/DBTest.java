import java.util.*;
import java.util.ArrayList;
//Manuel Fernandez
//Maf170330
//CS 3354.003

public class DBTest {
	List<String> foodList = new ArrayList<String>();
	List<String> memberList = new ArrayList<String>();
	
	public DBTest(){
		foodList.add("Pizza");
		foodList.add("Burger");
		foodList.add("Soda");
		foodList.add("Fries");
		foodList.add("Salad");
		
		
	}
	
	public boolean isFood(String food){
		
		//Returns true if food string exists in the arraylist, false if otherwise
		return foodList.contains(food);
	}
	
	public void newFood(String fd)
	{
		foodList.add(fd);
	}
	
	public boolean isMember(String member)
	{
		return foodList.contains(member);
	}
	
	public void newMember(String username)
	{
		memberList.add(username);
	}
	public void msg(){
        System.out.println("Please pick your food from this list: ");
        System.out.println(foodList);
 }
	
	public String returnMsg(){
        return "Please pick your food from this list: ";
        
 }
	
	public String returnList()
	{
		return foodList.toString();
	}
}
