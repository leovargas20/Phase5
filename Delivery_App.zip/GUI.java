import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.*;



public class GUI implements ActionListener{

	/**
	 * @param args
	 * @throws Throwable 
	 */
	//Labels
	private static final String DEFAULT_MENU_DISPLAY = "Welcome back! \n Please select from the following options:";
	private static final String ACCOUNT_CREATION_DISPLAY = "Please type in your desired credentials:";
	private static final String ACCOUNT_LOGIN_DISPLAY = "Please type in your credentials:";
	private static final String ACCOUNT_INVALID_DISPLAY = "Invalid Credentials, Please try again:";
	private static final String ACCOUNT_CREATE_INVALID_DISPLAY = "Invalid username, please try again";
	
	private static boolean isUser;
	
	private static Account acc1;
	private static Employee emp;
	private static Order order;
	private static DBTest db;
	
	private static JLabel userLabel;
	private static JLabel passwordLabel;
	private static JLabel optionMenu;
	private static JLabel orderLabel;
	private static JLabel orderList;
	private static JLabel wordText;
	private static JLabel success;
	
	//private static JFrame frame;
	private static JTextField userText;
	private static JTextField orderText;
	private static JPasswordField passwordText;
	
	//Buttons
	private static JButton button1;
	private static JButton button2;
	private static JButton button3;
	private static JButton button4;
	
	private static JButton submitButton;
	private static JButton loginButton;
	private static JButton orderButton;
	
	public GUI(){
		
		isUser = false;
		
	}
	
	public static void setOrderButtons(boolean b)
	{
		orderButton.setVisible(b);
		orderText.setVisible(b);
		orderLabel.setVisible(b);
		orderList.setVisible(b);
	}
	
	public static void setMenuButtons(boolean b)
	{
		button1.setVisible(b);
		button2.setVisible(b);
		button3.setVisible(b);
		button4.setVisible(b);
	}
	
	public static void setLoginButtons(boolean b, boolean t)
	{
		userLabel.setVisible(b);
		userText.setVisible(b);
		passwordLabel.setVisible(b);
		passwordText.setVisible(b);
		
		
		if (t && b)
		{
			submitButton.setVisible(b);
		}
		else if (!t && b)
		{
			loginButton.setVisible(b);
		}
		else if (!b)
		{
			submitButton.setVisible(b);
			loginButton.setVisible(b);
		}
		
	}
	
	public static void display()
	{
		JFrame frame = new JFrame("Delivery INC");
		
		
		JPanel panel = new JPanel();
		frame.setSize(420, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.add(panel);
		
		panel.setLayout(null);
		
		optionMenu = new JLabel(DEFAULT_MENU_DISPLAY);
		optionMenu.setBounds(30,20,400,80);
		panel.add(optionMenu);
		
		orderLabel = new JLabel("Please pick your food from this list:");
		orderLabel.setBounds(30,20,400,80);
		orderLabel.setVisible(false);
		panel.add(orderLabel);
		
		success = new JLabel("You have successfully logged in as an employee!");
		success.setBounds(30,50,400,80);
		success.setVisible(false);
		panel.add(success);
		
		orderList = new JLabel("");
		orderList.setBounds(30,50,400,80);
		orderList.setVisible(false);
		panel.add(orderList);
		
		userLabel = new JLabel("User: ");
		userLabel.setBounds(50,100,80,25);
		userLabel.setVisible(false);
		panel.add(userLabel);
		
		userText = new JTextField(20);
		userText.setBounds(150,100,165,25);
		userText.setVisible(false);
		panel.add(userText);
		
		orderText = new JTextField(20);
		orderText.setBounds(50,130,165,25);
		orderText.setVisible(false);
		panel.add(orderText);
		
		
		passwordLabel = new JLabel("Password: ");
		passwordLabel.setBounds(50,140,80,25);
		passwordLabel.setVisible(false);
		panel.add(passwordLabel);
		
	
		
		passwordText = new JPasswordField();
		passwordText.setBounds(150,140,165,25);
		passwordText.setVisible(false);
		panel.add(passwordText);
		
		/*JButton button = new JButton( new AbstractAction("LOGIN") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
	        	
	    		System.out.println(user + " " + pass);
	    		success.setText("Login!");
	        }
	    });
		button.setVisible(false);
		button.setBounds(10,80,80,25);
		*/
		
		
		/// USER ACC BUTTON
		button1 = new JButton( new AbstractAction("Create user account") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
                setMenuButtons(false);
                setLoginButtons(true, true);
                optionMenu.setText(ACCOUNT_CREATION_DISPLAY);
                isUser = true;
	        }
	    });
		button1.setBounds(10,110,180,25);
		panel.add(button1);
		
		/// USER LOGIN BUTTON
		button2 = new JButton( new AbstractAction("User login") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
	        	setMenuButtons(false);
                setLoginButtons(true, false);
                optionMenu.setText(ACCOUNT_LOGIN_DISPLAY);
                isUser = true;
	        }
	    });
		button2.setBounds(210,110,180,25);
		panel.add(button2);
		
		
		// EMPLOYEE CREATE ACCOUNT
		button3 = new JButton( new AbstractAction("Employee login") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
	        	setMenuButtons(false);
                setLoginButtons(true, false);
                optionMenu.setText(ACCOUNT_LOGIN_DISPLAY);
                isUser = false;
	        }
	    });
		button3.setBounds(210,150,180,25);
		panel.add(button3);
		
		
		// EMPLOYEE CREATE ACCOUNT
		button4 = new JButton( new AbstractAction("Create employee account") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
	        	setMenuButtons(false);
                setLoginButtons(true, true);
                optionMenu.setText(ACCOUNT_CREATION_DISPLAY);
                isUser = false;
	        }
	    });
		button4.setBounds(10,150,180,25);
		panel.add(button4);
		
		
		submitButton = new JButton( new AbstractAction("Submit") {
			@Override
	        public void actionPerformed( ActionEvent e ) {
				String user = userText.getText();
	    		String pass = passwordText.getText();
				if (acc1.check(user))
				{
		            if (isUser)
		            {
		            	
			    		
			    		//user = keyboard.next();
		                acc1.setUserName(user);
		                acc1.setPassword(pass);
		                System.out.println("Success!");
		            }
		            else
		            {
			    		//user = keyboard.next();
		                emp.setUserName(user);
		                emp.setPassword(pass);
		                System.out.println("Success!");
	
		            	
		            }
		            setMenuButtons(true);
	                setLoginButtons(false,false);
	                optionMenu.setText(DEFAULT_MENU_DISPLAY);
				}
				else
				{
					optionMenu.setText(acc1.checkDisplay(user));
				}
	            
	            
	            
	        }
	    });
		submitButton.setBounds(50,200,180,25);
		submitButton.setVisible(false);
		panel.add(submitButton);
		
		loginButton = new JButton( new AbstractAction("Login") {
			@Override
	        public void actionPerformed( ActionEvent e ) {
	            if (isUser)
	            {
	            	String user = userText.getText();
		    		String pass = passwordText.getText();
		    		
		    		//user = keyboard.next();
		    		if(user.equals(acc1.getUser()) && pass.equals(acc1.getPassword())){
	                    
		    			orderList.setText(db.returnList());
		    			setMenuButtons(false);
		                setLoginButtons(false,false);
		                setOrderButtons(true);
		                
		                
		                optionMenu.setText("");

		    		}
		    		else
		    		{
		    			optionMenu.setText(ACCOUNT_INVALID_DISPLAY);
		    		}
	                   
	                //System.out.println("Success!");
	            }
	            else
	            {
	            	String user = userText.getText();
		    		String pass = passwordText.getText();
		    		
		    		
	              
		    		if(user.equals(emp.getUser()) && pass.equals(emp.getPassword())) {
		    			optionMenu.setText("Welcome, " + user + "!");
		    			setLoginButtons(false,false);
		    			success.setVisible(true);
		    			
		    		}
		    		else
		    		{
		    			optionMenu.setText(ACCOUNT_INVALID_DISPLAY);
		    			
		    		}	            	
	            }
	            
	            
	           
	        }
	    });
		loginButton.setBounds(50,200,180,25);
		loginButton.setVisible(false);
		panel.add(loginButton);
		
		
		orderButton = new JButton( new AbstractAction("Order") {
	        @Override
	        public void actionPerformed( ActionEvent e ) {
	        	
	        	String food = orderText.getText();
	        	boolean ans = db.isFood(food);
	        	
	        	if(ans){
                    order.setFood(food);
                    optionMenu.setText(order.send());
                    setMenuButtons(false);
                    setLoginButtons(false, false);
                    setOrderButtons(false);
	        	}
	        	
	        	else
	        	{
	        		orderLabel.setText("Invalid food, try again:");
	        	}

	        }
	    });
		orderButton.setBounds(50,180,180,25);
		orderButton.setVisible(false);
		panel.add(orderButton);
		
		
		frame.setVisible(true);
	}
	
    public static void main(String[] args){
            int choice;
            String user;
            String password;
            String food;
        
            acc1 = new Account();
            emp = new Employee();
            GUI main = new GUI();
            order = new Order();
            db = new DBTest();
            
            ///////////////
            //  FRAME
            ////////////////
            
            //new GUI();
            
           
            display();

           
                
           
            
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		//String user = userText.getText();
		//String pass = passwordText.getText();
		
		
		
		
	}        
	
	
	
	
	
	
	

}
